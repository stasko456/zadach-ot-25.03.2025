﻿using project_21;

class Program
{
    public static void Main(string[] args)
    {
        Shape circle = ShapeFactory.GetShape("CIRCLE");
        Shape rectangle = ShapeFactory.GetShape("RECTANGLE");
        circle.Draw();    
        rectangle.Draw(); 
    }
}