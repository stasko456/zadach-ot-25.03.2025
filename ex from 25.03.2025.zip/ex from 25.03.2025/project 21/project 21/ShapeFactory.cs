﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_21
{
    public class ShapeFactory
    {
        public static Shape GetShape(string shape)
        {
            if (shape == "CIRCLE")
            {
                return new Circle();
            }
            else if (shape == "RECTANGLE")
            {
                return new Rectangle();
            }
            return null;
        }
    }
}
