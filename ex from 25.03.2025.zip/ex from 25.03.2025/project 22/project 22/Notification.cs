﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_22
{
    public abstract class Notification
    {
        public abstract void Send();
    }
}
