﻿using project_23;
using System.Security.Cryptography.X509Certificates;

class Program
{
    public static void Main(string[] args)
    {
        Shape circle = ShapeFactory.GetShape("circle");
        circle.Draw();

        Shape rectangle = ShapeFactory.GetShape("rectangle");
        rectangle.Draw();
    }
}