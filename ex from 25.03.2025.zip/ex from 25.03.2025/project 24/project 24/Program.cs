﻿namespace project_24
{
    using project_24;
    internal class Program
    {
        static void Main(string[] args)
        {
            Shape circle = ShapeFactory.GetShape("circle");
            circle.Draw();

            Shape rectangle = ShapeFactory.GetShape("rectangle");
            rectangle.Draw();
        }
    }
}
