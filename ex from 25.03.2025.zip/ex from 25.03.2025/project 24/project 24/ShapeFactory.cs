﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_24
{
    public class ShapeFactory
    {
        public static Shape GetShape(string shape)
        {
            if (shape == "circle")
            {
                return new Circle();
            }
            else if (shape == "rectangle")
            {
                 return new Rectangle();
            }
            return null;
        }
    }
}
