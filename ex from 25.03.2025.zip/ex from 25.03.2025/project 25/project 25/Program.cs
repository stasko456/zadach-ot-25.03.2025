﻿namespace project_25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NotificationCreator emailCreator = new EmailNotificationCreator();
            Notification emailNotification = emailCreator.CreateNotification();
            emailNotification.Send();

            NotificationCreator smsCreator = new SMSNotificationCreator();
            Notification smsNotification = smsCreator.CreateNotification();
            smsNotification.Send();
        }
    }
}
