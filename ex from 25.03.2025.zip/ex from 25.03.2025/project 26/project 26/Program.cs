﻿using System.Xml.Serialization;

namespace project_26
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NotificationCreator emailCreator = new EmailNotificationCreator();
            Notification emailNotification = emailCreator.CreateNotification();
            emailNotification.Send();

            NotificationCreator smsCreator = new SMSNotificationCreator();
            Notification smsNotification = smsCreator.CreateNotification();
            smsNotification.Send();
        }
    }
}
