﻿namespace project_27
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dispatcher dispatcher = new Dispatcher();
            Handler handler = new Handler();
            dispatcher.NameChange += handler.OnDispatcherNameChange;

            Console.WriteLine("Write a name that the dispatcher will change it to:");
            string input = Console.ReadLine();
            while (input != "End")
            {
                dispatcher.Name = input;
                input = Console.ReadLine();
            }
        }
    }
}
