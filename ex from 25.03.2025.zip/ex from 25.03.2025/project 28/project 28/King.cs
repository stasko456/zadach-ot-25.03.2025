﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_28
{
	public delegate void KingAttack();

    public class King
    {
		private string name;

		public event KingAttack OnAttack;

		public string Name
		{
			get { return this.name; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("The name of the king cannot be null or empty!");
				}
				else
				{
                    this.name = value;
                } 
			}
		}

        public King(string name)
        {
            this.Name = name;
        }

		public void Attack()
		{
            Console.WriteLine($"King {this.Name} is under attack!");
            if (this.OnAttack != null)
            {
                this.OnAttack();
            }
        }
    }
}
