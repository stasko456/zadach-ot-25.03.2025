﻿using System.Runtime.CompilerServices;

namespace project_28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string,Footman> footmans = new Dictionary<string,Footman>();
            Dictionary<string, RoyalGuard> royalGuards = new Dictionary<string, RoyalGuard>();

            Console.WriteLine("Enter the king's name:");
            string nameOfKing = Console.ReadLine();
            King king = new King(nameOfKing);
            Console.WriteLine("-----------------------");

            Console.WriteLine("Enter some names for footmans:");
            string[] footmanNames = Console.ReadLine().Split(' ').ToArray();
            foreach (string footmanName in footmanNames)
            {
                if (!footmans.ContainsKey(footmanName))
                {
                    Footman footman = new Footman(footmanName);
                    footmans[footmanName] = footman;
                    king.OnAttack += footman.ResponseToAttack;
                }
            }

            Console.WriteLine("Enter some names for royal guards:");
            string[] royalGuardNames = Console.ReadLine().Split(' ').ToArray();
            foreach (string royalGuardName in royalGuardNames)
            {
                if (!royalGuards.ContainsKey(royalGuardName))
                {
                    RoyalGuard royalGuard = new RoyalGuard(royalGuardName);
                    royalGuards[royalGuardName] = royalGuard;
                    king.OnAttack += royalGuard.ResponseToAttack;
                }
            }

            string[] input = Console.ReadLine().Split(',').ToArray();
            while (input[0] != "End")
            {
                switch (input[0])
                {
                    case "Attack King":
                        king.Attack();
                        break;
                    case "Kill":
                        if (footmans.ContainsKey(input[1]))
                        {
                            king.OnAttack -= footmans[input[1]].ResponseToAttack;
                            footmans.Remove(input[1]);
                        }
                        else if (royalGuards.ContainsKey(input[1]))
                        {
                            king.OnAttack -= royalGuards[input[1]].ResponseToAttack;
                            royalGuards.Remove(input[1]);
                        }
                        break;
                    default:
                        break;
                }
                input = Console.ReadLine().Split(',').ToArray();
            }
        }
    }
}
