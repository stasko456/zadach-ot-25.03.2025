﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_28
{
    public class RoyalGuard
    {
        private string name;

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The name of the royal guard cannot be null or empty!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public RoyalGuard(string name)
        {
            this.Name = name;
        }

        public void ResponseToAttack()
        {
            Console.WriteLine($"Royal Guard {this.Name} is defending!");
        }
    }
}
